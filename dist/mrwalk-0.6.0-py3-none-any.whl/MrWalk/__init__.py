from .mrwalk import MrWalk

"""
MrWalk

A Python library that allows retrieving a directory info recursively
"""

__version__ = "0.1.0"
__author__ = 'Marco Antonio Calviño Coira'
__credits__ = '2025 MitsSoft'

MrWalk = MrWalk